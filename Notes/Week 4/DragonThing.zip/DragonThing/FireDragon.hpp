//
//  FireDragon.hpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 8/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#ifndef FireDragon_hpp
#define FireDragon_hpp

#include <stdio.h>
class FireDragon {};

#endif /* FireDragon_hpp */
