//
//  FireDragon.cpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 8/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#include "FireDragon.hpp"


