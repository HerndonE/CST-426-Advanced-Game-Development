//
//  DragonMesh.hpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 7/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#ifndef DragonMesh_hpp
#define DragonMesh_hpp

#include <stdio.h>

class DragonMesh{};

#endif /* DragonMesh_hpp */
