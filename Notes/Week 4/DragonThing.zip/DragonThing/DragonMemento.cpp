//
//  DragonMemento.cpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 7/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#include "DragonMemento.hpp"
#include "Dragon.hpp"

DragonMemento::DragonMemento(std::string type, int currHp){
    this->type = type;
    this->currHp = currHp;
    };

std::string DragonMemento::getType(){
    return this->type;
};
int DragonMemento::getCurrHp(){
    return this->currHp;
};
