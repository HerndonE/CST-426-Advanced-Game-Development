#include <iostream>
#include "main.h"
#include "Dragon.hpp"
#include "DragonMemento.hpp"

using namespace std;


int main() {
    DragonMesh mesh;
    Dragon hoid = Dragon("fire",500, 42, &mesh);
  std::cout << "Hello World I am a " << hoid.getType() << " dragon" << std::endl;
}
