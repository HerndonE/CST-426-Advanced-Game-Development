//
//  DragonMemento.hpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 7/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#ifndef DragonMemento_hpp
#define DragonMemento_hpp

#include <stdio.h>
//#include "Dragon.hpp"
#include <iostream>

class DragonMemento{
private:
    int currHp;
    std::string type;
public:
    DragonMemento(std::string type, int currHp);
    std::string getType();
    int getCurrHp();
    
};

#endif /* DragonMemento_hpp */
