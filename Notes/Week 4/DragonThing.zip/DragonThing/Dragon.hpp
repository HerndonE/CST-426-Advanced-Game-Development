//
//  Dragon.hpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 7/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#ifndef Dragon_hpp
#define Dragon_hpp

#include <stdio.h>
#include <string.h>
#include <iostream>

#include "DragonMesh.hpp"
#include "DragonMemento.hpp"


class Dragon{
protected:
    std::string type;
    DragonMesh* mesh;
    int maxHp;
    int currHp;
    int attack;
    Dragon(DragonMesh* mesh);
public:
    std::string getType();
    void setType(std::string type);

    int getMaxHp();
    
    void setMaxHp(int maxHp);

    int getCurrHp();

    void setCurrHp(int currHp);

    int getAttack();

    Dragon(std::string type, int maxHp, int attack, DragonMesh* mesh);

    DragonMemento* getMemento();
    
    Dragon getDragonFromMemento(DragonMemento memento);
};


#endif /* Dragon_hpp */
