//
//  Dragon.cpp
//  DragonThing
//
//  Created by Drew Clinkenbeard on 7/30/20.
//  Copyright © 2020 Drew Clinkenbeard. All rights reserved.
//

#include "Dragon.hpp"
#include "DragonMesh.hpp"

class FireDragon : Dragon{
    public:
        FireDragon(DragonMesh* mesh):Dragon(mesh){
            this->type = "fire";
            this->maxHp = 100;
            this->attack = 50;
        }
    FireDragon(DragonMesh* mesh, DragonMemento* memento):Dragon(mesh){
        this->type = "fire";
        this->maxHp = 100;
        this->attack = 50;
        this->setCurrHp(memento->getCurrHp());
    }
};

class IceDragon : Dragon{
    public:
        IceDragon(DragonMesh* mesh):Dragon(mesh){
            this->type = "Ice";
            this->maxHp = 300;
            this->attack = 15;
        }
};

class LighteningDragon : Dragon{
    public:
        LighteningDragon(DragonMesh* mesh):Dragon(mesh){
            this->type = "Lightening";
            this->maxHp = 200;
            this->attack = 25;
        }
};


    
       
        Dragon::Dragon(DragonMesh* mesh){
            this->mesh = mesh;
        }
    
        std::string Dragon::getType(){
            return this->type;
        };
        void Dragon::setType(std::string type){
            this->type = type;
        }

        int Dragon::getMaxHp(){
            return this->maxHp;
        }

        void Dragon::setMaxHp(int maxHp){
            this->maxHp = maxHp;
        }

        int Dragon::getCurrHp(){
            return this->currHp;
        }

        void Dragon::setCurrHp(int currHp){
            this->currHp = currHp;
        }

        int Dragon::getAttack(){
            return this->attack;
        }

        Dragon::Dragon(std::string type,
               int maxHp,
               int attack,
               DragonMesh* mesh){
            this->type = type;
            this->currHp = this->maxHp = maxHp;
            this->attack = attack;
            this->mesh = mesh;
        }
    
    DragonMemento* Dragon::getMemento(){
        return new DragonMemento(this->type,this->currHp);
    };

Dragon Dragon::getDragonFromMemento(DragonMemento memento){
//     type = memento.getType();
//    if(type.compare("fire") == 0){
//        DragonMesh mesh = DragonMesh();
//        FireDragon* f = FireDragon(mesh, memento& );
//
//        return  f;
//    }else if (type.compare("ice") == 0){
//        return 0;
//    }
    
    return 0;
};
