﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Command {
	protected bool completed = false;
	public virtual bool isCompleted(){
		return completed;
	}
	public abstract void executeCommand ();
}

public class Attack : Command {
	private Transform goal;
	private Transform npc;
	public Attack (Transform goal, Transform npc){
		this.goal = goal;
		this.npc = npc;
	}
	public override void executeCommand() {
		npc.position = goal.position;
		npc.position += new Vector3 (Random.Range (0f, .9f), Random.Range (0f, .9f), Random.Range (0f, .9f));
	}
	public override bool isCompleted(){
		return false;
	}
}
public class WaitBeforeAttack : Command {
	double time = 0;

	public override void executeCommand() {
		time += Time.deltaTime;
	}
	public override bool isCompleted(){
		return time > 3;
	}	
}

public class FlyToGoal : Command {
	private Transform goal;
	private Transform npc;
	private Vector3 step;

	public FlyToGoal (Transform goal, Transform npc){
		this.goal = goal;
		this.npc = npc;
		step = (goal.position - npc.position) / 200;
	}

	public override void executeCommand(){
		npc.position += step;
	}

	public override bool isCompleted(){
		return (npc.position - goal.position).magnitude < 2;
	}

}
public class DragonBehaviourCommand : MonoBehaviour {

	Queue<Command> queueOfCommands; 
	public Transform goal;
		
	void Start() {
		queueOfCommands = new Queue<Command> ();
		queueOfCommands.Enqueue (new FlyToGoal (goal, transform));
		queueOfCommands.Enqueue (new WaitBeforeAttack ());
		queueOfCommands.Enqueue (new Attack (goal, transform));
	}

	// Update is called once per frame
	void Update () {
		Command current = queueOfCommands.Peek();
		current.executeCommand ();
		if (current.isCompleted ())
			queueOfCommands.Dequeue ();
	}
}

