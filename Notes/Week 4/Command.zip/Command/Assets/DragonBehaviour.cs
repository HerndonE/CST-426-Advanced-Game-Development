﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonBehaviour : MonoBehaviour {

	public Transform goal;
	public Vector3 step;
	int timer = 0;

	void Start () {
		step = (goal.position - transform.position)/300;
	}
		
	bool NearGoal() {
		return (transform.position - goal.position).magnitude < 2;
	}

	void FlyToGoal(){
		transform.position += step;
	}
	bool TimerStarted ()
	{
		return timer > 0;
	}
		
	bool TimerFinished ()
	{
		return timer == 2;
	}

	IEnumerator  StartTimer (){
		timer = 1;
		yield return new WaitForSeconds(1);
		timer = 2;
	}

	void Attack() {
		transform.position = goal.position;
		transform.position += new Vector3 (Random.Range (0f, .9f), Random.Range (0f, .9f), Random.Range (0f, .9f));
	}

	// Update is called once per frame
	void Update () {

		if	(!	NearGoal())	{	
			FlyToGoal();	
		}	else	if	(!	TimerStarted())	{	
			StartCoroutine(StartTimer());	
		}	else	if	(TimerFinished())	{	
			Attack();	
		}
		
	}
}
