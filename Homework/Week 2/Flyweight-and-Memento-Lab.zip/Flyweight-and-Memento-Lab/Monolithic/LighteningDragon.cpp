#include <iostream> // header in standard library
using namespace std;

class LightningDragon{  
  int id = 3; 
  int xp = 75;
  double HP = 150; 
  string loot = " silver sword,";
  string size = " medium, ";
};
