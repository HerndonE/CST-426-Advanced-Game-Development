#include <iostream> // header in standard library
using namespace std;

class IceDragon{
  int id = 2; 
  int xp = 75;
  double HP = 150; 
  string loot = "bronze sword, ";
  string size = "small, ";
};
