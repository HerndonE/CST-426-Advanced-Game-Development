#include <iostream>
using namespace std;

class FireDragon{
  int id = 1; 
  int xp = 75;
  double HP = 150; 
  string loot = "gold sword, ";
  string size = "large, ";
};