#include "Memento.h"
class LightningDragon : Dragon{

};