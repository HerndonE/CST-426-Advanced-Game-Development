#include "Memento.h"
class FireDragon : Dragon{

};