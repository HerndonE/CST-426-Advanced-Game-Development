#include "Memento.h"
class IceDragon : Dragon{

};
